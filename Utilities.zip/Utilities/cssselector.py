from selenium import webdriver
 
# create webdriver object
driver = webdriver.Chrome()
 
# enter keyword to search
keyword = "geeksforgeeks"
 
# get geeksforgeeks.org
driver.get("https://www.geeksforgeeks.org/")
 
# get element
element = driver.find_element(By.cssSelector, "input.gsc-i-id2")
 
# print complete element
print(element)