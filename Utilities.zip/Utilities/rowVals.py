import openpyxl
loc = "D:\Work\Rishabh\Motilal\motilaloswalapidocumentation\scriplist121.xlsx"
wb_obj = openpyxl.load_workbook(loc)
sheet = wb_obj.active
scripCode = sheet['C']
scripName = sheet['X']
print(len(scripName))
print(scripName[1].value)
print(scripCode[1].value)
res = {scripName[i].value: scripCode[i].value for i in range(len(scripName))}
#print ("Resultant dictionary is : " +  str(res))
print(res["BANKNIFTY30JUN29400CE"])
print(str(res))
#for cell in c:
#    print(cell.value)
"""for row in sheet.iter_rows(min_row=1, max_row=sheet.max_row):
	for cell in row:
        print()
            print(sheet.cell(row=cell, column=3))"""