import openpyxl
loc = "D:\Work\Rishabh\Motilal\motilaloswalapidocumentation\scriplist1.xlsx"
wb_obj = openpyxl.load_workbook(loc)
sheet_obj = wb_obj.active
scripcolobj = sheet_obj['C']
sheet1_obj=scripcolobj[2: sheet_obj.max_row]
scripnamecolobj = sheet_obj['D']
#sheet_obj = sheet_obj[2:sheet_obj.max_row]
MFScripcolobj = sheet_obj['C']
zscripnamecolobj = sheet_obj['X']
sheet_obj.cell(row=1,column=24).value = "ZScripName"
rowVal = 2
#eg scripname from zerodha - BANKNIFTY 30-Jun-2022 PE 29300
for row_cell in scripnamecolobj:
    val = row_cell.value
    if(val != 'scripname'):
        list0 = val.split()
        print(list0[0] + " " + list0[1])
        list2 = list0[1].split("-")
        list2[1].upper()
        print(len(list0))
        print(len(list2))
        if(len(list0) == 4 and len(list2) == 3):
            MFScripName = list0[0]+list2[0]+list2[1].upper()+list0[3]+list0[2]
            print(MFScripName)
            sheet_obj.cell(row=rowVal, column=24).value = MFScripName
        rowVal+=1
wb_obj.save("D:\Work\Rishabh\Motilal\motilaloswalapidocumentation\scriplist12.xlsx")