import requests,json,time,datetime, os
import pandas as pd, numpy as np, math
import pickle, redis, telegram
from scipy.stats import norm
rRr = redis.Redis(host='127.0.0.1', port=6379, db=0)

### BS functions
def BS_call_vol(S, K, r, T, target_value, q): # Spot, Strike, Risk-free return, Time to maturity, market price, dividend
    MAX_ITERATIONS = 200
    PRECISION = 1.0e-5
    sigma = 0.5
    for i in range(0, MAX_ITERATIONS):
        price = BS_call_price(S, K, r, T, q, sigma)
        vega = BS_vega(S, K, r, T, sigma)
        diff = target_value - price  # our root
        if (abs(diff) < PRECISION):
            return sigma
        sigma = sigma + diff/vega # f(x) / f'(x)
    return sigma # value wasn't found, return best guess so far

def BS_call_price(S, K, r, t, q, sigma): # Spot, Strike, Risk-free return, Time to maturity, Dividend, sigma
    d1 = 1 / (sigma * np.sqrt(t)) * ( np.log(S/K) + (r - q + sigma**2/2) * t)
    d2 = d1 - sigma * np.sqrt(t)
    C = norm.cdf(d1) * S * np.exp(-q * t)- norm.cdf(d2) * K * np.exp(-r * t)
    return C

def BS_DeltaC (S, K, r, t, q, sigma): # Spot, Strike, Risk-free return, Time to maturity, Dividend, Call Volatility
    d1 = 1 / (sigma * np.sqrt(t)) * ( np.log(S/K) + (r - q + sigma**2/2) * t)
    d2 = d1 - sigma * np.sqrt(t)
    DC = np.exp(-q * t) * norm.cdf(d1)
    return DC

def BS_vega(S, K, r, T, sigma): # Spot, Strike, Risk-free return, Time to maturity, volatility
    d1 = (np.log(S / K) + (r + 0.5 * sigma ** 2) * T) / (sigma * np.sqrt(T))
    return S * norm.pdf(d1) * np.sqrt(T)

def BS_put_vol(S, K, r, T, target_value, q): # Spot, Strike, Risk-free return, Time to maturity, market price, dividend
    MAX_ITERATIONS = 200
    PRECISION = 1.0e-5
    sigma = 0.5
    for i in range(0, MAX_ITERATIONS):
        price = BS_put_price(S, K, r, T, q, sigma)
        vega = BS_vega(S, K, r, T, sigma)
        diff = target_value - price  # our root
        if (abs(diff) < PRECISION):
            return sigma
        sigma = sigma + diff/vega # f(x) / f'(x)
    return sigma # value wasn't found, return best guess so far

def BS_put_price(S, K, r, t, q, sigma): # Spot, Strike, Risk-free return, Time to maturity, Dividend, sigma
    d1 = 1 / (sigma * np.sqrt(t)) * ( np.log(S/K) + (r - q + sigma**2/2) * t)
    d2 = d1 - sigma * np.sqrt(t)
    P = - S * np.exp(-q * t) * norm.cdf(-d1) + K * np.exp(-r * t) * norm.cdf(-d2)
    return P

def BS_DeltaP (S, K, r, t, q, sigma): # Spot, Strike, Risk-free return, Time to maturity, Dividend, Put Volatility
    d1 = 1 / (sigma * np.sqrt(t)) * ( np.log(S/K) + (r - q + sigma**2/2) * t)
    d2 = d1 - sigma * np.sqrt(t)
    DP = -np.exp(-q * t) * norm.cdf(-d1)
    return DP