from selenium import webdriver
from selenium.webdriver import DesiredCapabilities
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from urllib.parse import urlparse, parse_qs

from kiteconnect import KiteConnect
import requests,json,time,datetime, os
import pandas as pd, numpy as np
import time, random, redis, pyotp, pickle, datetime
rRr = redis.Redis(host='127.0.0.1', port=6379, db=0)
from utility_main import *

def get_request_token(AC):
    print("req token get")
    url_ = "https://kite.trade/connect/login?api_key=" + AC['api_key'] + "&v=3"
    print(url_)
    print("#"*30,AC['Name'],"#"*30)
    options = Options()
    print("a")
    #options.set_headless(headless=True)
    #options.add_argument("--headless")
    options.add_argument('headless')
    print("b")
    driver = webdriver.Chrome(options=options, executable_path='D:\Work\Rishabh\exes\chromedriver_win32\chromedriver.exe')
    print ("Headless Chrome Initialized")
    driver.get(url_)

    print(driver.current_url)
    time.sleep(random.sample([5,6,7],1)[0])
    print('Title :: ',driver.title)
    print('Current URL :: ',driver.current_url)
    
    driver.find_element_by_css_selector("""div#container input[type="text"]""").send_keys(AC['USER_ID'])
    #driver.find_element("""div#container input[type="text"]""").send_keys(AC['USER_ID'])
    print("Login ID Submitted")
    time.sleep(random.sample([2,3,4],1)[0])
    driver.find_element_by_css_selector("""div#container input[type="password"]""").send_keys(AC['PASS'])
    #driver.find_element("""div#container input[type="password"]""").send_keys(AC['PASS'])
    print("Login Pass Submitted")
    time.sleep(random.sample([2,3,4],1)[0])
    driver.find_element_by_css_selector("""div#container button[type="submit"]""").click()
    #driver.find_element("""div#container button[type="submit"]""").click()
    print("Login ID Pass CLICK")
    time.sleep(random.sample([5,6,7],1)[0])
    URL = driver.current_url
    print(URL)
    newUrl = driver.current_url
    """while(newUrl == URL):
        newUrl = driver.current_url
        time.sleep(5)"""
           
    print(URL)
    
    totp=pyotp.TOTP(AC['pin_gen']);current_pin=totp.now()
    while True:
        totp = pyotp.TOTP(AC['pin_gen'])
        new_pin = totp.now()
        print("Getting new pin at ", time_now(), "  ", new_pin)
        if new_pin!=current_pin or 1<=int(time_now().split(':')[-1])<=18 or 31<=int(time_now().split(':')[-1])<=48:break
        time.sleep(2)

    URL = driver.current_url
    print(URL)
    driver.find_element_by_css_selector("""#totp""").send_keys(new_pin)
    print("TOTP Entered")
    time.sleep(random.sample([1, 2, 3], 1)[0])
    URL = driver.current_url
    print(URL)
    driver.find_element_by_css_selector("""div#container button[type="submit"]""").click()
    print("PIN Submitted - ", new_pin)
    time.sleep(random.sample([5,6,7],1)[0])
    URL = driver.current_url
    print("url after sleep")
    print(URL)
    parsed_url = urlparse(URL)
    print(parsed_url)
    url_elements = parse_qs(parsed_url.query)
    print(url_elements['sess_id'])
    request_token = url_elements['request_token'][0]
    print(request_token)
    driver.quit()
    print("Request token generated Successfully")
    return request_token
    
def login_and_create_session(AC,request_token):
    print("Lcstest")
    api_key = AC['api_key']
    api_secret = AC['api_secret']
    print("---------------------------------------------------")
    print("Generating Kite Session")
    kite = KiteConnect(api_key)
    tokens = kite.generate_session(request_token, api_secret)
    print('Kite session generated')
    kite.set_access_token( tokens["access_token"] )
    print('Initializing Kite access tokens')
    access_token = tokens["access_token"]
    public_token = tokens["public_token"]
    user_id = tokens["user_id"]
    auth = "&api_key="+api_key+"&access_token="+access_token
    print('All tokens generated')
    print("Zerodha -- Logged in Successfully for %s at '%s'"%(kite.profile()['user_name'],time_now())); print("#"*65)
    login_credentials={'kite':kite,'access_token':access_token,'public_token':public_token,
                       'user_id':user_id,'auth':auth,'api_key':api_key,'api_secret':api_secret,
                       'update_time':str(datetime.datetime.now())}
    return login_credentials
    
