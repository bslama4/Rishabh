from kiteconnect import KiteConnect
import pickle, redis, random, telegram
import requests,json,time,datetime, os, math
import pandas as pd, numpy as np
rRr = redis.Redis(host='127.0.0.1', port=6379, db=0)
from utility_main import *
from telegram_details import telegram_activated_bots, telegram_msg
##########################

from flask import Flask, redirect, url_for, render_template, request, flash, make_response
import os

app = Flask(__name__, template_folder=os.getcwd()+"\\User Interface\\", static_folder=os.getcwd()+"\\User Interface\\")
##########################

def generateOTP() :
    digits = "0123456789"
    OTP = ""
    for i in range(6) :
        OTP += digits[math.floor(random.random() * 10)] 
    return OTP
all_OTP={}

def generate_current_pnl_table():
    col_head = ['User ID','Name','N_Delta_Neutral', 'BN_Delta_Neutral']
    all_ac_info=pickle.loads(rRr.get('all_ac_info'))
    try:
        PnL=pickle.loads(rRr.get('PnL'))
        user_data=[]
        for x,y in all_ac_info.items():
            row=[x,all_ac_info[x]['Name']]
            for strategy in ['N_Delta_Neutral', 'BN_Delta_Neutral']:
                row.append(int(PnL[x][strategy]))
            user_data.append(row)
        template_inputs = {'col_head':col_head,
                           'user_data':user_data}
    except Exception as p:
        print(str(p),time_now())
        user_data=[]
        for x,y in all_ac_info.items():
            row=[x,all_ac_info[x]['Name']]
            for strategy in ['N_Delta_Neutral', 'BN_Delta_Neutral']:
                row.append('-')
            user_data.append(row)
        template_inputs = {'col_head':col_head,
                           'user_data':user_data}
    return template_inputs

@app.route('/', methods=['GET','POST'])
def main_page():
    from telegram_details import telegram_activated_bots, telegram_msg
    return render_template('main_page.html')

@app.route('/OTP', methods=['GET','POST'])
def login_otp():
    from telegram_details import telegram_activated_bots, telegram_msg
    user_id = request.form.get('user_id').lower()
    if user_id=='admin':
        resp = make_response(render_template('otp_page.html', **{'user_name':'Rishab'}))
        resp.set_cookie('user_id', user_id)
        all_OTP[user_id] = {'otp':generateOTP(), 'validity':time.time()+60*5}
        tele_msg="OTP to login is %s, valid for next 5 minutes"%(all_OTP[user_id]['otp'])
        telegram_msg(tele_msg);print(all_OTP[user_id]['otp'])
        return resp
    else:
        return render_template('incorrect_user_or_otp.html')
    
@app.route('/verify', methods=['GET','POST'])
def validate_my_otp():
    from telegram_details import telegram_activated_bots, telegram_msg
    try:
        OTP_rec = request.form.get('OTP_rec')
        user_id = request.cookies.get('user_id')
        if OTP_rec==all_OTP[user_id]['otp'] and all_OTP[user_id]['validity']>time.time():
            resp = make_response(redirect('/home'))
            resp.set_cookie('login_status', user_id + '_' + str(time.time()+60*60*7).split('.')[0])
            return resp
        else: return render_template('incorrect_user_or_otp.html')
    except Exception as e:
        print(str(e))
        return render_template('incorrect_user_or_otp.html')

@app.route('/home', methods=['GET','POST'])
def home_page():
    from telegram_details import telegram_activated_bots, telegram_msg             
#     try:
    login_status = request.cookies.get('login_status')
    try:
        user_id, login_valid_time = login_status.split('_')[0], login_status.split('_')[1]
        if int(login_valid_time)<time.time(): return render_template('main_page.html')
    except:
        user_id='admin'
    template_inputs = generate_current_pnl_table()
    resp = make_response(render_template('home_page.html', **template_inputs))
    resp.set_cookie('login_status', user_id + '_' + str(time.time()+60*60*7).split('.')[0])  
    return resp
#     except Exception as e:
#         print(str(e))
#         return render_template('main_page.html')

@app.route('/exit', methods=['GET','POST'])
def exit_trade():
    from telegram_details import telegram_activated_bots, telegram_msg    
    try:
        login_status = request.cookies.get('login_status')
        user_id, login_valid_time = login_status.split('_')[0], login_status.split('_')[1]
        if int(login_valid_time)<time.time(): return render_template('main_page.html')
        
        strategy_name = request.form.get('strategy_name')
        rRr.set('EXIT_'+strategy_name,'1')
        telegram_msg("Exit Input saved for %s :)"%(strategy_name))
    except Exception as e:
        print(str(e))
        telegram_msg("Invalid Input, Please try again in correct format :: "+str(e))
    
    template_inputs = generate_current_pnl_table()
    resp = make_response(render_template('home_page.html', **template_inputs))
    resp.set_cookie('login_status', user_id + '_' + str(time.time()+60*60*7).split('.')[0])  
    return resp

@app.route('/pnl', methods=['GET','POST'])
def pnl_page():
    all_ac_df = pd.read_excel('ALL_AC.xlsx')
    all_ac_df = all_ac_df[all_ac_df['Type'].notna()]
    all_ac_info = all_ac_df.to_dict('records')
    for info in all_ac_info:
        info['USER_ID']=str(info['USER_ID'])
    all_ac_main_info = {x['USER_ID']:x for x in all_ac_info}

    col_head = ['Id','Name','N_Delta_Neutral', 'BN_Delta_Neutral','Txn charges']
    col_head = [' '*10+c+' '*10 for c in col_head]
    pnl_folder = os.getcwd() + "\\pnl\\"
    user_data=[]

    for x,y in all_ac_main_info.items():
        row_data=[x, y['Name']]
        try:
            db_input = open(pnl_folder+x+'\\MTD', 'rb')
            MTD_pnl = pickle.load(db_input)
            db_input.close()
            for pl in ['N_Delta_Neutral', 'BN_Delta_Neutral','charges']:
                row_data.append(MTD_pnl[pl])
        except:
            row_data.extend(['-']*10)
        user_data.append(row_data)
    template_inputs = {'col_head':col_head,
                       'user_data':user_data}
    resp = make_response(render_template('pnl.html', **template_inputs))
    return resp
    
if __name__ == '__main__':
    app.run(host='0.0.0.0',port=80)
    # app.run(host='localhost',port=80)
