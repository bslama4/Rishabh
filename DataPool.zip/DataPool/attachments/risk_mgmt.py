print("#####------------------------------#####")
print("STARTING *RISK MANAGEMENT* CODE")
print("#####------------------------------#####")

from kiteconnect import KiteConnect
import pickle, redis, random, telegram
import requests,json,time,datetime, os, math
import pandas as pd, numpy as np
rRr = redis.Redis(host='127.0.0.1', port=6379, db=0)
from utility_main import *
from multiprocessing import Process
from telegram_details import telegram_activated_bots, telegram_msg

##### Get inputs
workers_count=1
lots_per_order_freeze_BN=48; qty_per_lot_BN=25
lots_per_order_freeze_N=56; qty_per_lot_N=50
market_start_time = datetime.time(9, 14, 15)
market_close_time = datetime.time(15, 29, 0)
#---------------

while True:
    decision = market_hours(open_time = market_start_time)
    
    if decision=='OPEN':
        # print('##### MARKET OPEN :: Sync in Strategy #####')
        break
    get_up_time=datetime.datetime.fromtimestamp(decision+time.time()).strftime('%H:%M:%S %A, %d-%b-%Y')
    print('Login Credentials will be updated again @ ',get_up_time)
    time.sleep(decision)

from telegram_details import telegram_activated_bots, telegram_msg
telegram_msg("Initiating Risk management setup")
# -----------------------

# -----------------------
def get_list_of_qty(lot_qty, lots_per_order_freeze):
    list_of_qty = []
    while lot_qty>0:
        if lot_qty<lots_per_order_freeze:
            list_of_qty.append(lot_qty)
            lot_qty=0
        else:
            list_of_qty.append(lots_per_order_freeze)
            lot_qty-=lots_per_order_freeze
    return list_of_qty

inst_req = pickle.loads(rRr.get('inst_REQ'))
token_info_req = pickle.loads(rRr.get('token_info_REQ'))
inst_req_BN = pickle.loads(rRr.get('inst_BN'))
token_info_req_BN = pickle.loads(rRr.get('token_info_BN'))
inst_req_N = pickle.loads(rRr.get('inst_N'))
token_info_req_N = pickle.loads(rRr.get('token_info_N'))
  
def place_verify_price(login_credentials, trans_pos, trading_symbol, lot_size, lot_qty, strategy_tag):
    ordr_tried=0;    order_place_timestamp=datetime.datetime.now()
    while ordr_tried<2:
        try:
            print("Placing %s Order for %s"%(trans_pos, trading_symbol))
            order_id = login_credentials['kite'].place_order(tradingsymbol=trading_symbol,
                                                         transaction_type = trans_pos,
                                                         quantity = lot_size*lot_qty,
                                                         order_type = 'MARKET',
                                                         exchange = 'NFO',
                                                         product='MIS', variety='regular', tag=strategy_tag)
            ordr_tried+=1
            return verify_order(login_credentials,order_id)
        except Exception as e:
            time.sleep(.5); ordr_tried+=1; print(trading_symbol, ' : EXCEPTION : ',time_now(), ' :: ', str(e))
            all_orders = login_credentials['kite'].orders()
            strategy_orders = [o for o in all_orders if o['tag']==strategy_tag]
            new_placed_orders = [o for o in strategy_orders if o['order_timestamp']>=order_place_timestamp]
            if len(new_placed_orders)>0: return verify_order(login_credentials,new_placed_orders[0]['order_id'])
    return 0 # i.e. no order_id generated

def verify_order(login_credentials,order_id_req, check_count=3, CANCEL=True):
    tried=0
    while check_count>tried:
        try:
            order_details = login_credentials['kite'].order_history(order_id_req)
            if 'COMPLETE' in [x['status'] for x in order_details]:
                trade_info = [x for x in order_details if x['status']=='COMPLETE'][0]
                return trade_info['average_price'] # i.e. number greater than 0
            if 'REJECTED' in [x['status'] for x in order_details]:
                trade_info = [x for x in order_details if x['status']=='REJECTED'][0]
                return 'REJECTED :: ' + trade_info['status_message'] # Str
            tried+=1
            print("Order still open, will check in a while again")
            time.sleep(1)
        except:
            tried+=1
            print("Waiting for Order Id to fetch details")
            time.sleep(2)
    try:
        if CANCEL:
            login_credentials['kite'].cancel_order(order_id=order_id_req, variety='regular')
            print("Cancelling the Order as was not filled")
        else: print("Leaving order OPEN and not cancelling it")
    except:pass
    return False
# -----------------------

def generate_reversal_trade(alist):
    if alist[-1]>0:trans_pos='SELL'
    if alist[-1]<0:trans_pos='BUY'
    lot_qty=abs(alist[-1])
    return [alist[0],trans_pos,lot_qty]
# -----------------------

pubsub = rRr.pubsub()
pubsub.subscribe(['SQUARE_OFF_ALL'])
print("Reading from Multi Workers, waiting for Signals...@ Risk Manager ")

for item in pubsub.listen():
    all_ac_info = pickle.loads(rRr.get('all_ac_info'))

    if datetime.datetime.today().time() > market_close_time:
        pubsub.unsubscribe()
        break
    if item['channel'].decode() == 'SQUARE_OFF_ALL':
        try:order_data = pickle.loads(item['data'])['order_data']
        except:continue
        
        user_id = order_data['client_info']['USER_ID']
        unique_id = "%s (%s) :: "%(order_data['client_info']['Name'],order_data['client_info']['USER_ID'])
        login_credentials = order_data['client_info']['login_credentials']
        tele_msg = order_data['signal_info']['telegram_msg']
        algo_id = order_data['signal_info']['ALGO']
        strategy_tag = order_data['signal_info']['ALGO']
        client_info = order_data['client_info']
        qty_multiple = order_data['client_info']['Qty Multiple']
        
        if algo_id in ['BN_Delta_Neutral']:
            lot_size=qty_per_lot_BN
            lots_per_order_freeze=lots_per_order_freeze_BN
        elif algo_id in ['N_Delta_Neutral']:
            lot_size=qty_per_lot_N
            lots_per_order_freeze=lots_per_order_freeze_N
    
        tried=0
        while tried<3:
            tried+=1
            all_orders = login_credentials['kite'].orders()
            strategy_orders = [o for o in all_orders if o['tag']==strategy_tag and o['status']=='COMPLETE']
            all_trades={}
            for s in strategy_orders:
                if s['tradingsymbol'] not in all_trades: all_trades[s['tradingsymbol']]={'qty':0}
                if s['transaction_type']=='BUY':all_trades[s['tradingsymbol']]['qty']+=s['quantity']
                if s['transaction_type']=='SELL':all_trades[s['tradingsymbol']]['qty']-=s['quantity']
            reverse_open_orders = [generate_reversal_trade([x,y['qty']]) for x,y in all_trades.items() if y['qty']!=0]
            tele_msg = unique_id + 'Number of open trades :: Reversing All :: ' + str(len(reverse_open_orders))
            telegram_msg(tele_msg);    print(reverse_open_orders)
            if len(reverse_open_orders)==0:break
            for t in reverse_open_orders:
                for q in get_list_of_qty(t[2]/lot_size, lots_per_order_freeze):
                    avg_price = place_verify_price(login_credentials, t[1], t[0], lot_size,int(q), strategy_tag)
                    print(avg_price, time_now())
                    time.sleep(1)
            time.sleep(5)


print("#####------------------------------#####")
print("CLOSING CODE")
telegram_msg("Closing *RISK MANAGEMENT* CODE")
print("#####------------------------------#####")
time.sleep(300)