import os, datetime, time
import redis, pickle
rRr = redis.Redis(host='127.0.0.1', port=6379, db=0)

nse_calendar = {datetime.date(2022, 1, 26): 'Republic Day',
                datetime.date(2022, 3, 1): 'Mahashivratri',
                datetime.date(2022, 3, 18): 'Holi',
                datetime.date(2022, 4, 14): 'Dr.Baba Saheb Ambedkar Jayanti',
                datetime.date(2022, 4, 15):  'Good Friday',
                datetime.date(2022, 5, 3): 'Id-Ul-Fitr (Ramzan ID)',
                datetime.date(2022, 8, 9): 'Moharram',
                datetime.date(2022, 8, 15): 'Independence Day',
                datetime.date(2022, 8, 31): 'Ganesh Chaturthi',
                datetime.date(2022, 10, 5): 'Dussehra',
                datetime.date(2022, 10, 24): 'Diwali-Laxmi Pujan',
                datetime.date(2022, 10, 26): 'Diwali-Balipratipada',
                datetime.date(2022, 11, 8): 'Gurunanak Jayanti' }
                
def market_hours(open_time = datetime.time(9, 0, 0)):
    date_today = datetime.datetime.today().date()
    day_today = time.strftime("%A", time.localtime())
    if date_today in nse_calendar or day_today in ['Saturday', 'Sunday']:
        return 60*60*8

    close_time = datetime.time(19, 29, 59)
    market_time_open1 = datetime.datetime.today().time() > open_time
    market_time_open2 = datetime.datetime.today().time() < close_time
    if market_time_open1 and market_time_open2:
        return 'OPEN'

    current = datetime.datetime.time(datetime.datetime.now())
    diff = datetime.datetime.combine(datetime.date.today(), open_time) - datetime.datetime.combine(datetime.date.today(), current)
    sleep_secs = diff.seconds + 5
    get_up_time=datetime.datetime.fromtimestamp(sleep_secs+time.time()).strftime('%Y-%m-%d %H:%M:%S %A')
    print('System at sleep :), will wake up again @ ',get_up_time)
    return sleep_secs
    
def wake_up_time(wakeup_at = datetime.time(9, 15, 0)):
    current = datetime.datetime.time(datetime.datetime.now())
    diff = datetime.datetime.combine(datetime.date.today(), wakeup_at) - datetime.datetime.combine(datetime.date.today(), current)
    sleep_secs = diff.seconds + .51
    get_up_time=datetime.datetime.fromtimestamp(sleep_secs+time.time()).strftime('%Y-%m-%d %H:%M:%S %A')
    print('System at sleep :), will wake up again @ ',get_up_time)
    return sleep_secs
   
def time_now():return datetime.datetime.fromtimestamp(time.time()).strftime('%H:%M:%S')