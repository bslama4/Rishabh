import os, datetime, time, json
import redis,pickle, telegram
rRr = redis.Redis(host='127.0.0.1', port=6379, db=0)

#---------------
#telegram_bots = [{'name':'RK_BOT','token':'5192886613:AAG1UoQm6JG17l71xBTBzE5X_gS7Wrzk3MQ'}]
#MASTER_CHAT_ID = "RK_Auto_trade"
telegram_bots = [{'name':'XoxozBot','token':'5559841479:AAGCZdoFLp3MI-o01H3DRDcE4T1YJcILLF0'}]
MASTER_CHAT_ID = "Xoxoz_Auto_trade"
#---------------

telegram_activated_bots = [telegram.Bot(token=t['token']) for t in telegram_bots]

def telegram_msg(msg, chat_id=MASTER_CHAT_ID):
    tried=0
    while tried<3:
        try:
            print(msg)
            #telegram_activated_bots[0].sendMessage(chat_id="@" + chat_id, text=msg)
            break
        except:
            tried+=1; time.sleep(.5)
