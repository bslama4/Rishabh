import os,sys

import pickle, redis, random, telegram
import requests,json,time,datetime, os, math
import pandas as pd, numpy as np
from kiteconnect import KiteConnect
rRr = redis.Redis(host='127.0.0.1', port=6379, db=0)
from utility_main import *
from telegram_details import telegram_activated_bots, telegram_msg

trade_folder = os.getcwd() + "\\trade details\\"
pnl_folder = os.getcwd() + "\\pnl\\"
trade_date = str(datetime.datetime.now().date()).replace('-','_')

##### Get inputs
market_start_time = datetime.time(9, 15, 0)
market_close_time = datetime.time(15, 29, 0)
#---------------

def zerodha_charges(buy_price, sell_price, qty):
    buy_turnover=buy_price*qty
    sell_turnover=sell_price*qty
    if buy_price==0 or sell_price==0:brokerage=20
    else:brokerage = 20*2    # Both side brokerage
    nse_trans_charges = (.053/100)*(buy_turnover+sell_turnover) # NSE trans charges .053% on premium
    gst = .18*(brokerage + nse_trans_charges) # 18% on (brokerage & NSE trans charges)
    stt_ctt = (.05/100)*sell_turnover # STT/CTT .05% on sell premium
    sebi_charges = (10/10000000)*(buy_turnover+sell_turnover) # SEBI charges 10/crore
    stamp_charges = (.003/100)*buy_turnover # Stamp charges .003% on buy side
    return brokerage+nse_trans_charges+gst+stt_ctt+sebi_charges+stamp_charges

def add_pnl(pnl1, pnl2):
    new_dict={'N_Delta_Neutral':0, 'BN_Delta_Neutral':0, 'charges':0}
    for algo in ['N_Delta_Neutral', 'BN_Delta_Neutral']:
        new_dict[algo] = pnl1[algo] + pnl2[algo]
    new_dict['charges'] = pnl1['charges'] + pnl2['charges']
    return new_dict
# -----------------------

def generate_pnl():
    all_ac_info=pickle.loads(rRr.get('all_ac_info'))
    for x,y in all_ac_info.items():
        x=str(x)
        user_pnl = {'N_Delta_Neutral':0, 'BN_Delta_Neutral':0, 'charges':0}
        all_orders = y['login_credentials']['kite'].orders()
        for strategy_tag in ['N_Delta_Neutral', 'BN_Delta_Neutral']:
            strategy_orders = [o for o in all_orders if o['tag']==strategy_tag and o['status']=='COMPLETE']
            all_trades={}
            for s in strategy_orders:
                if s['tradingsymbol'] not in all_trades: all_trades[s['tradingsymbol']]={'qty':0}
                if s['transaction_type']=='BUY':all_trades[s['tradingsymbol']]['qty']+=s['quantity']
                if s['transaction_type']=='SELL':all_trades[s['tradingsymbol']]['qty']-=s['quantity']

            buy_amt=0;sell_amt=0
            for inst,qt in all_trades.items():
                if qt['qty']!=0:continue
                for s in strategy_orders:
                    if s['tradingsymbol']!=inst:continue
                    if s['transaction_type']=='BUY':
                        user_pnl['charges']+= zerodha_charges(float(s['average_price']),0,s['quantity'])
                        buy_amt+= float(s['average_price'])*s['quantity']
                    if s['transaction_type']=='SELL':
                        user_pnl['charges']+= zerodha_charges(0,float(s['average_price']),s['quantity'])
                        sell_amt+= float(s['average_price'])*s['quantity']
            user_pnl[strategy_tag]=round(sell_amt-buy_amt,0)
        user_pnl['charges']=round(user_pnl['charges'],0)
        if x not in os.listdir(pnl_folder):os.mkdir(pnl_folder+x)
        db_input = open(pnl_folder+x+'\\'+trade_date, 'wb')
        pickle.dump(user_pnl, db_input)
        db_input.close()

        all_pnl = os.listdir(pnl_folder+x)
        if 'MTD' in all_pnl: all_pnl.remove('MTD')

        MTD_pnl = {'N_Delta_Neutral':0, 'BN_Delta_Neutral':0, 'charges':0}
        for pl in all_pnl:
            d=[int(x) for x in pl.split('_')]
            if datetime.date.today().month==d[1] and datetime.date.today().year==d[0]:
                db_input = open(pnl_folder+x+'\\'+pl, 'rb')
                daily_pnl = pickle.load(db_input)
                db_input.close()
                MTD_pnl = add_pnl(MTD_pnl, daily_pnl)
        db_input = open(pnl_folder+x+'\\MTD', 'wb')
        pickle.dump(MTD_pnl, db_input)
        db_input.close()

        print("P&L generated for ",x)
        tele_msg = '%s (%s)'%(y['Name'],x) + ' :: P&L for the day \n\n'
        for xx,yy in user_pnl.items():
            tele_msg+=xx + ' :: ' + str(yy) + '\n'
        telegram_msg(tele_msg);time.sleep(1)
        print("#####------------------------------#####")


if __name__ == "__main__":
    print("#####------------------------------#####")
    print("STARTING *P&L Check* CODE")
    print("#####------------------------------#####")

    while True:
        decision = market_hours(open_time = market_start_time)
        if decision=='OPEN':
            print('##### MARKET OPEN :: Sync in Strategy #####')
            break
        get_up_time=datetime.datetime.fromtimestamp(decision+time.time()).strftime('%H:%M:%S %A, %d-%b-%Y')
        print('Login Credentials will be updated again @ ',get_up_time)
        time.sleep(decision)

    from telegram_details import telegram_activated_bots, telegram_msg
    telegram_msg("Initiating P&L Check Code")
    # -----------------------
    
    login_credentials = pickle.loads(rRr.get('MASTER_login'))
    inst_req = pickle.loads(rRr.get('inst_REQ'))
    token_info_req = pickle.loads(rRr.get('token_info_REQ'))
    all_ac_info=pickle.loads(rRr.get('all_ac_info'))
    PnL={x:{'N_Delta_Neutral':0, 'BN_Delta_Neutral':0} for x,y in all_ac_info.items()}

    while datetime.datetime.today().time()<market_close_time:
        all_ac_info=pickle.loads(rRr.get('all_ac_info'))
        try:all_prices = login_credentials['kite'].ltp(inst_req.instrument_token.tolist())
        except Exception as l:
            print(time_now(),str(l)); continue
        for x,y in all_ac_info.items():
            try:
                all_orders = y['login_credentials']['kite'].orders()
                for strategy_tag in ['N_Delta_Neutral', 'BN_Delta_Neutral']:
                    PnL[x][strategy_tag]=0
                    strategy_orders = [o for o in all_orders if o['tag']==strategy_tag and o['status']=='COMPLETE']
                    for s in strategy_orders:
                        if s['transaction_type']=='BUY':
                            PnL[x][strategy_tag]+=(all_prices[str(s['instrument_token'])]['last_price'] - s['average_price'])*s['quantity']
                        if s['transaction_type']=='SELL':
                            PnL[x][strategy_tag]+=(-all_prices[str(s['instrument_token'])]['last_price'] + s['average_price'])*s['quantity']

            except Exception as e:
                print(x,str(e),time_now())
            time.sleep(.5)
        
        rRr.set('PnL', pickle.dumps(PnL))
        print('PnL Updated @ ',time_now())
        time.sleep(5)

    print("#####------------------------------#####")
    print("CLOSING CODE")
    telegram_msg("Closing *P&L Check* CODE")
    print("#####------------------------------#####")
    time.sleep(300)