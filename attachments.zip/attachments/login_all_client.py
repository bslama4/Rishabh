print("#####------------------------------#####")
print("STARTING NEW LOGIN CODE")
print("#####------------------------------#####")

from kiteconnect import KiteConnect
import requests,json,time,datetime, os
import pandas as pd, numpy as np
import pickle, redis, telegram
rRr = redis.Redis(host='127.0.0.1', port=6379, db=0)
# -----------------------
from login import get_request_token,login_and_create_session
from utility_main import *
# -----------------------

"""while True:
    decision = market_hours(open_time = datetime.time(8, 45, 0))
    if decision=='OPEN':
        print('##### MARKET OPEN :: Logging in #####')
        break
    get_up_time=datetime.datetime.fromtimestamp(decision+time.time()).strftime('%H:%M:%S %A, %d-%b-%Y')
    print('Login Credentials will be updated again @ ',get_up_time)
    time.sleep(decision)"""

# -----------------------
from telegram_details import telegram_activated_bots, telegram_msg
telegram_msg("Initiating Auto-Login for Clients")
# -----------------------

all_ac_df = pd.read_excel('ALL_AC.xlsx')
all_ac_df = all_ac_df[all_ac_df['Type'].notna()]
all_ac_info = {x['USER_ID']:x for x in all_ac_df.to_dict('records')}
for x,y in all_ac_info.items():y['Logged_In']=False

for x,y in all_ac_info.items():    
    try:
        print("test")
        print(x)
        print(y)
        print("test1")
        request_token = get_request_token(y)
        login_credentials = login_and_create_session(y,request_token)
        print("test")
        y['login_credentials'] = login_credentials
        y['Logged_In'] = True
        telegram_msg("Logged in successfully to Zerodha Account @ %s -- "%(y['Name']) + time_now())
        if y['Type']=='Master':
            rRr.set('MASTER_login', pickle.dumps(login_credentials))
            print('MASTER Login credentials Hosted Successfully')
            telegram_msg('MASTER Login credentials Hosted Successfully')
            print(login_credentials['kite'].profile())
            print('Fetching all instrument list')
            instrument_id = login_credentials['kite'].instruments()
            inst_ALL = pd.DataFrame(instrument_id)
            rRr.set('inst_ALL', pickle.dumps(inst_ALL))
            print('Intrument Ids Hosted Successfully')
            telegram_msg('All Instruments Fetched Successfully')
            print("###########################################################")
    except Exception as e:
        telegram_msg("Login Exception :: " + str(e) + " @ %s -- "%(y['Name']) + time_now())
    rRr.set('all_ac_info', pickle.dumps(all_ac_info)); time.sleep(.5)

print("---------------------------------------------------")
rRr.set('all_ac_info', pickle.dumps(all_ac_info))
telegram_msg('All scheduled clients for auto-login Logged in Successfully')
print("---------------------------------------------------")

MASTER_login = pickle.loads(rRr.get('MASTER_login'))
inst = pickle.loads(rRr.get('inst_ALL'))
print(MASTER_login['kite'].profile())
print("---------------------------------------------------")
sleep_secs = wake_up_time(wakeup_at = datetime.time(15, 35, 0))
time.sleep(sleep_secs)

print("#####------------------------------#####")
telegram_msg('Closing Auto-Login code for the day')
print("Done for the day, closing code successfully")
print("#####------------------------------#####")
