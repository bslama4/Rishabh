print("#####------------------------------#####")
print("STARTING *ORDER MANAGEMENT* CODE")
print("#####------------------------------#####")

from kiteconnect import KiteConnect
import pickle, redis, random, telegram
import requests,json,time,datetime, os, math
import pandas as pd, numpy as np
rRr = redis.Redis(host='127.0.0.1', port=6379, db=0)
from utility_main import *

##### Get inputs
workers_count=3
lots_per_order_freeze_BN=48; qty_per_lot_BN=25
lots_per_order_freeze_N=56; qty_per_lot_N=50
market_start_time = datetime.time(9, 14, 0)
market_close_time = datetime.time(15, 29, 0)
#---------------

assigned_worker=0 # Initializing
#---------------

while True:
    decision = market_hours(open_time = market_start_time)
    
    if decision=='OPEN':
        print('##### MARKET OPEN :: Sync in Strategy #####')
        break
    get_up_time=datetime.datetime.fromtimestamp(decision+time.time()).strftime('%H:%M:%S %A, %d-%b-%Y')
    print('Login Credentials will be updated again @ ',get_up_time)
    time.sleep(decision)

from telegram_details import telegram_activated_bots, telegram_msg
telegram_msg("Initiating Order management setup")
# -----------------------

all_ac_info=pickle.loads(rRr.get('all_ac_info'))

pubsub = rRr.pubsub()
pubsub.subscribe(['ORDER_MGMT_SYS','TOGGLE_ALGO_ON_OFF'])
print("Reading market, waiting for Signals.....")

for item in pubsub.listen():
    all_ac_info=pickle.loads(rRr.get('all_ac_info'))
    #-----
    
    if datetime.datetime.today().time() > market_close_time:
        for i in range(workers_count):
            rRr.publish('ORDER_WORKER_'+str(i), json.dumps({1:1}))
        rRr.publish('SQUARE_OFF_ALL', json.dumps({1:1}))
        pubsub.unsubscribe()
        break
    #-----
    
    if item['channel'].decode() == 'TOGGLE_ALGO_ON_OFF':
        try:data = json.loads(item['data'])
        except:continue
        msg_noti = "%s %s for user %s"%(data['toggle_this'][0],{True:'Started', False:'Stopped'}[data['toggle_this'][1]],data['user_id'])
        all_ac_info[data['user_id']][data['toggle_this'][0]]=data['toggle_this'][1]
        rRr.set('all_ac_info', pickle.dumps(all_ac_info))
        telegram_msg(msg_noti); print(msg_noti)
    #-----
        
    if item['channel'].decode() == 'ORDER_MGMT_SYS':
        try:data = json.loads(item['data'])
        except:continue
        telegram_msg(data['telegram_msg'])
        for x,y in all_ac_info.items():
            if y['Logged_In'] and y[data['ALGO']]:
                time.sleep(y['Delay'])
                print('User %s assigned to worker number %d @'%(y['Name'],assigned_worker),time_now())
                rRr.publish('ORDER_WORKER_'+str(assigned_worker), pickle.dumps({'signal_info':data,'client_info':y}))
                
                if assigned_worker==(workers_count-1):assigned_worker=0
                else:assigned_worker+=1


print("#####------------------------------#####")
print("CLOSING CODE")
telegram_msg("Closing *ORDER MANAGEMENT* CODE")
print("#####------------------------------#####")
time.sleep(300)

print("#####------------------------------#####")
print("Generating P&L for all Users")
telegram_msg("Generating P&L for all Users")
print("#####------------------------------#####")

from pnl_mgmt import *
from telegram_details import telegram_activated_bots, telegram_msg
time.sleep(1)
generate_pnl()

print("#####------------------------------#####")
