from MOFSLOPENAPI import MOFSLOPENAPI
from kiteconnect import KiteConnect
import pickle, redis, random, telegram
import requests,json,time,datetime, os, math
import pandas as pd, numpy as np
rRr = redis.Redis(host='127.0.0.1', port=6379, db=0)
from utility_main import *
from multiprocessing import Process
from telegram_details import telegram_activated_bots, telegram_msg
import os
import openpyxl
import logging
#from datetime import datetime, date, timedelta
"""from datetime import date, timedelta
from datetime import time
from datetime import datetime"""

"""logfilename = os.path.join(os.getcwd(), "Logs", datetime.now().strftime("%Y%m%d-%H%M%S"))
logfilename += '.txt'
logging.basicConfig(filename=logfilename,format='%(asctime)s,%(msecs)d %(levelname)-8s [%(filename)s:%(lineno)d] %(message)s',
                    datefmt='%Y-%m-%d:%H:%M:%S',
                    level=logging.DEBUG)
logger = logging.getLogger(__name__)
print("init " + logfilename)
logging.debug("init " + logfilename)"""


##### Get inputs
workers_count=3
lots_per_order_freeze_BN=48; qty_per_lot_BN=25
lots_per_order_freeze_N=56; qty_per_lot_N=50
market_start_time = datetime.time(9, 14, 15)
market_close_time = datetime.time(15, 29, 0)
#---------------

ApiKey = "Ml0OD6kVF4lFyzmb" 

# userid and password are trading account username and password
userid = "MD01880" 
#password = "abc@123"
password = "New123"   
Two_FA = "16/09/1988"
vendorinfo = "MD01880"
clientcode = "MD01880"


# Set Url for LIVE or UAT Testing
# Enter Base Url 
Base_Url = "https://uatopenapi.motilaloswal.com" #UAT server
#Base_Url = "https://openapi.motilaloswal.com" #Production server


# Initialize MofslOpenApi using Apikey and Base_Url
Mofsl = MOFSLOPENAPI(ApiKey, Base_Url)
def TradeStatus_on_message(ws2, message_type, message):
#have to write at trade details 
    if message_type == "TradeStatus":
        print(message)
        
Mofsl._TradeStatus_on_message = TradeStatus_on_message

loc = "D:\Work\Rishabh\Motilal\motilaloswalapidocumentation\scriplist121.xlsx"
wb_obj = openpyxl.load_workbook(loc)
sheet = wb_obj.active
scripCode = sheet['C']
scripName = sheet['X']
scripCodeDict = {scripName[i].value: scripCode[i].value for i in range(len(scripName))}
#print ("Resultant dictionary is : " +  str(res))
   
# Login by Clientcode and password
print("--------------------------------Login--------------------------------")
#print(Mofsl.login(userid, password, Two_FA))
#print("test")
print(Mofsl.login(userid, password, Two_FA, vendorinfo))
print("login done")


        
while True:
    decision = market_hours(open_time = market_start_time)
    
    if decision=='OPEN':
        # print('##### MARKET OPEN :: Sync in Strategy #####')
        break
    get_up_time=datetime.datetime.fromtimestamp(decision+time.time()).strftime('%H:%M:%S %A, %d-%b-%Y')
    print('Login Credentials will be updated again @ ',get_up_time)
    time.sleep(decision)

# -----------------------
def get_list_of_qty(lot_qty, lots_per_order_freeze):
    list_of_qty = []
    while lot_qty>0:
        if lot_qty<lots_per_order_freeze:
            list_of_qty.append(lot_qty)
            lot_qty=0
        else:
            list_of_qty.append(lots_per_order_freeze)
            lot_qty-=lots_per_order_freeze
    return list_of_qty

inst_req = pickle.loads(rRr.get('inst_REQ'))
token_info_req = pickle.loads(rRr.get('token_info_REQ'))
inst_req_BN = pickle.loads(rRr.get('inst_BN'))
token_info_req_BN = pickle.loads(rRr.get('token_info_BN'))
inst_req_N = pickle.loads(rRr.get('inst_N'))
token_info_req_N = pickle.loads(rRr.get('token_info_N'))

def place_verify_price(login_credentials, trans_pos, trading_symbol, lot_size, lot_qty, strategy_tag):
    order_place_timestamp=datetime.datetime.now()
    print("Placing %s Order for %s"%(trans_pos, trading_symbol))
    quantity = lot_size*lot_qty
    symboltoken = scripCodeDict[trading_symbol]
    Orderinfo = {"clientcode":clientcode, "exchange":"NFO", "symboltoken":symboltoken, "buyorsell":trans_pos, "ordertype":"MARKET", "producttype":"MIS", "orderduration":"GTD", "quantityinlot":quantity, "disclosedquantity":0, "amoorder":"N", "tag":"strategy_tag"}
    """order_id = login_credentials['kite'].place_order(tradingsymbol=trading_symbol,
                                                         transaction_type = trans_pos,
                                                         quantity = lot_size*lot_qty,
                                                         order_type = 'MARKET',
                                                         exchange = 'NFO',
                                                         product='MIS', variety='regular', tag=strategy_tag)"""
    orderID = Mofsl.PlaceOrder(Orderinfo)
    return orderID 

    """tried=0
    while check_count>tried:
        try:
            order_details = login_credentials['kite'].order_history(order_id_req)
            if 'COMPLETE' in [x['status'] for x in order_details]:
                trade_info = [x for x in order_details if x['status']=='COMPLETE'][0]
                return trade_info['average_price'] # i.e. number greater than 0
            if 'REJECTED' in [x['status'] for x in order_details]:
                trade_info = [x for x in order_details if x['status']=='REJECTED'][0]
                return 'REJECTED :: ' + trade_info['status_message'] # Str
            tried+=1
            print("Order still open, will check in a while again")
            time.sleep(1)
        except:
            tried+=1
            print("Waiting for Order Id to fetch details")
            time.sleep(2)
    try:
        if CANCEL:
            login_credentials['kite'].cancel_order(order_id=order_id_req, variety='regular')
            print("Cancelling the Order as was not filled")
        else: print("Leaving order OPEN and not cancelling it")
    except:pass
    return False"""

def reverse_trans_pos(pos):
    if pos=='BUY':return 'SELL'
    if pos=='SELL':return 'BUY'

# -----------------------

def write_trades(user_id, trade): #['Algo ver','strat pos','trade symbol','trans type','qty','price','time']
    try:
        user_id=str(user_id)
        trade_data_path = os.getcwd()+'\\trade details\\'
        trade_date = str(datetime.datetime.now().date()).replace('-','_')
        if trade_date not in os.listdir(trade_data_path):os.mkdir(trade_data_path+trade_date)
        trade_book_col = ['Algo version','strategy position','trading symbol','transaction type','trade quantity','trade price','trade time']
        if user_id+'.csv' not in os.listdir(trade_data_path+trade_date):        
            fo=open(trade_data_path+trade_date+'\\'+user_id+'.csv','a+')
            fo.write(','.join([str(x) for x in trade_book_col]))
            fo.write('\n'); fo.close()
        fo=open(trade_data_path+trade_date+'\\'+user_id+'.csv','a+')
        fo.write(','.join([str(x) for x in trade]))
        fo.write('\n'); fo.close()
    except Exception as e:
        print("Error writing trade for ",user_id,str(e))
# -----------------------

def WORKER_TASK(i):
    pubsub = rRr.pubsub()
    pubsub.subscribe(['ORDER_WORKER_'+str(i)])
    print("Reading from Order Mgmt sys, waiting for Signals...@ Worker ",i)

    for item in pubsub.listen():
        all_ac_info = pickle.loads(rRr.get('all_ac_info'))
        
        if datetime.datetime.today().time() > market_close_time:
            pubsub.unsubscribe()
            break
        if item['channel'].decode() == 'ORDER_WORKER_'+str(i):
            try:order_data = pickle.loads(item['data'])
            except:continue
            user_id = order_data['client_info']['USER_ID']
            unique_id = "%s (%s) :: "%(order_data['client_info']['Name'],order_data['client_info']['USER_ID'])
            login_cred = order_data['client_info']['login_credentials']
            tele_msg = order_data['signal_info']['telegram_msg']
            algo_id = order_data['signal_info']['ALGO']
            strategy_tag = order_data['signal_info']['ALGO']
            client_info = order_data['client_info']
            qty_multiple = order_data['client_info']['Qty Multiple']
            
            if algo_id in ['BN_Delta_Neutral']:
                lot_size=qty_per_lot_BN
                lots_per_order_freeze=lots_per_order_freeze_BN
            elif algo_id in ['N_Delta_Neutral']:
                lot_size=qty_per_lot_N
                lots_per_order_freeze=lots_per_order_freeze_N
            
            print(user_id, ' : ',time_now(), ' : ', algo_id, ' : ', order_data['signal_info']['SIGNALS'])
            ERROR=False
            if len(order_data['signal_info']['SIGNALS'])>0:
                for s in order_data['signal_info']['SIGNALS']:
                    qty_this_time = int(int(float(s[5]))*qty_multiple/lot_size)
                    if qty_this_time==0:continue
                    total_qty=0
                    for q in get_list_of_qty(qty_this_time, lots_per_order_freeze):
                        orderID = place_verify_price(login_cred, s[0], s[1], lot_size, q, strategy_tag)
                        print("OrderID is " + str(orderID))
                        """if 'REJECTED' in str(avg_price):
                            telegram_msg(unique_id+avg_price)
                            ERROR=True; break
                        if avg_price==0 or avg_price==False:
                            ERROR=True; break
                        write_trades(user_id,[algo_id,s[4],s[1],s[0],q,avg_price,time_now()])
                        total_qty+=q"""

                    if ERROR:
                        rRr.publish('TOGGLE_ALGO_ON_OFF', json.dumps({'user_id':user_id,'toggle_this':[algo_id, False]}))
                        telegram_msg(unique_id+"ERROR for %s: Closing %s"%(user_id, algo_id))
                        time.sleep(.5)
                        telegram_msg(unique_id+"REVERSING unbalanced trades")
                        rRr.publish('SQUARE_OFF_ALL', pickle.dumps({'order_data':order_data}))
                        break 
            else:
                print("Telegram msg for %s"%(user_id),time_now())

#---------------------

if __name__ == "__main__":
    print("#####------------------------------#####")
    print("STARTING *Multi Workers* CODE")
    print("#####------------------------------#####")
    print('##### MARKET OPEN :: Sync in Strategy #####')
    from telegram_details import telegram_activated_bots, telegram_msg
    telegram_msg("Initiating Multiple Workers...")

    procs = []
    for i in range(workers_count):
        proc = Process(target=WORKER_TASK, args=(i,))  # instantiating each worker
        procs.append(proc)
        proc.start()

    for proc in procs: # complete the processes
        proc.join()

    print("#####------------------------------#####")
    print("CLOSING *Multi Workers* CODE")
    print("#####------------------------------#####")
    telegram_msg("Closing all workers...")
    #sleep_secs = wake_up_time(wakeup_at = datetime.time(15,30,30))
    #time.sleep(sleep_secs)
    time.sleep(300)
